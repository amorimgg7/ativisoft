<?php

namespace MercadoPago\Resources\Preference;

/** DifferentialPricing class. */
class DifferentialPricing
{
    /** Differential pricing ID. */
    public ?int $id;
}
