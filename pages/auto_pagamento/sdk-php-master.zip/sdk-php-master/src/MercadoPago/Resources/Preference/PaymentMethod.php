<?php

namespace MercadoPago\Resources\Preference;

/** PaymentMethod class. */
class PaymentMethod
{
    /** Payment method ID. */
    public ?string $id;
}
