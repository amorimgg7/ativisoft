<?php

namespace MercadoPago\Resources\User;

/** BuyerReputationUnrated class. */
class BuyerReputationUnrated
{
    /** The number of paid unrated transactions. */
    public $paid;

    /** The total number of unrated transactions. */
    public $total;
}
