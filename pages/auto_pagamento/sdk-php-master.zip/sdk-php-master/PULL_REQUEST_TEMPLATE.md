## Changes made to the feature:
 * Item 1

## General changes
 * Item 1

## Issues closed
 * Closes #XX


## PR validation checklist:

- [ ] Title and clear description of the PR
- [ ] Tests of my functionality
- [ ] Documentation of my functionality
- [ ] Tests executed and passed
- [ ] Branch Coverage >= 80%
